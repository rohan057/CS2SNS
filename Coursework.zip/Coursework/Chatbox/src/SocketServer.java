import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import javax.net.ServerSocketFactory;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;

public class SocketServer {
    public static final boolean DEBUG = false;
    public static final String KEYSTORE_LOCATION = "C:/Users/rohan/Documents/Year 2 - University/CS2SNS/Coursework/Keys/ServerKeyStore.jks"; //links to the file created
    public static final String KEYSTORE_PASSWORD = "password"; //password of the file
    public static final int TLS_PORT = 4321; //port used for communication

    private static List<Socket> sockets = new ArrayList<>();

    public static void main(String[] args) throws Exception {

        System.setProperty("javax.net.ssl.keyStore", KEYSTORE_LOCATION); //links to file location
        System.setProperty("javax.net.ssl.keyStorePassword", KEYSTORE_PASSWORD);

        if (DEBUG) //allows us to see if the messages are being encrypted
            System.setProperty("javax.net.debug", "all");

        try {
            ServerSocketFactory s = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
            SSLServerSocket serverSocket = (SSLServerSocket) s.createServerSocket(TLS_PORT);
            System.out.println("Server connected."); //when the server is run it says it is connected

            while (true) {

                serverSocket.setEnabledProtocols(new String[] { "TLSv1.3", "TLSv1.2" });
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected."); //tells the server a new client has connected

                sockets.add(clientSocket);
                
                //creates new thread when new client is created
                Thread thread = new Thread(new IncomingMessageHandler(clientSocket));
                thread.start();

            }
} catch (IOException e) {
            System.out.println(
                    "Exception caught when trying to listen on port " + TLS_PORT + " or listening for a connection");
            System.out.println(e.getMessage());
        }
    }

    private static class IncomingMessageHandler implements Runnable {
        private Socket socket;

        public IncomingMessageHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try {
                BufferedReader read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String message;
                while ((message = read.readLine()) != null) {
                    broadcast(message, socket);
                }
            } catch (Exception e) {
                System.out.println("A client has disconnected from the chat."); //the server is told when a client disconnects
            } finally {
                System.out.println("A client has left the chat."); //the server is told when a client leaves the chat
            }
        }
    }

    private static void broadcast(String message, Socket socketDelivered) {
        if (message.equals("exit")) { //if the user types quit the socket is closed
            sockets.remove(socketDelivered);
        } else {
            for (Socket socket : sockets) {
                if (socket != null) { //if the socket is being used then the messages are displayed in the chat
                    try {
                        PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
                        output.println(message);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}