import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public class ClientSocket {

	public static final boolean DEBUG = false;
	public static final int TLS_PORT = 4321; //port used for communication
	public static final String TLS_HOST = "localhost";
	public static final String TRUSTTORE_LOCATION = "C:/Users/rohan/Documents/Year 2 - University/CS2SNS/Coursework/CA/ClientKeyStore.jks"; //links to the file created
	public static final String TRUSTTORE_PASSWORD = "password"; //password of the file
	public static final String AUTHENTICATION_PASSWORD = "pass123"; //password for users to be able join the chat

	public static void main(String[] args) throws Exception {

		System.setProperty("javax.net.ssl.trustStore", TRUSTTORE_LOCATION);
		System.setProperty("javax.net.ssl.trustStorePassword", TRUSTTORE_PASSWORD);

		try {
			 if (DEBUG) //allows us to see if the messages are being encrypted
			 System.setProperty("javax.net.debug", "all");

			SSLSocketFactory a = (SSLSocketFactory) SSLSocketFactory.getDefault();
			SSLSocket echoSocket = (SSLSocket) a.createSocket(TLS_HOST, TLS_PORT);

			echoSocket.startHandshake();
			BufferedReader user_Input = new BufferedReader(new InputStreamReader(System.in)); //reads the user input and puts it into the terminal for others to see

			Scanner scanner = new Scanner(System.in);
	        while (true) {
	            System.out.print("Enter the correct password to join the chat: ");
	            String password = scanner.nextLine();
	            if (password.equals(AUTHENTICATION_PASSWORD)) { //if the password entered is equal to declared variable then they are given access
	                // Allow the user to enter the chat
	                break;
	            } else {
	                System.out.println("Incorrect password. Please try again."); //if password doesn't match then they have to re-attempt to login
	            }
	        }

			System.out.print("Enter a username to join the chat: "); //asks user to enter a name
			String username = user_Input.readLine();

			PrintWriter output = new PrintWriter(echoSocket.getOutputStream(), true);

			output.println(username + " has joined the chat."); //displays the user who has joined the chat
			Thread thread = new Thread(new IncomingMessageHandler(echoSocket));
			thread.start();
			
			//limit on maximum messages sent starts here
		      int messagesAmount = 0;
		      int maxMessages = 100; //maximum number of messages per minute

			while (true) {
				String message = user_Input.readLine();

				if (message.equals("exit")) { // if the user types quit they are disconnected
					output.println(username + " has left the chat."); //tells everyone who has left the chat
					echoSocket.setSoTimeout(1000);
					break;
				} else {
					if (messagesAmount < maxMessages) { //if the number of messages entered by a user hasn't reached 100 their messages continue to be displayed
					output.println(username + ": " + message);
					messagesAmount++; //adds to the variable after every message that is sent
			          } else {
			            System.out.println("You have exceeded the maxium amount of messages for a session. You have now been disconnected!"); //tells the user why they have been disconnected when reaching 100 messages
			            System.exit(1); //disconnects the user from the chat
			          }
				}
			}

			echoSocket.close();
			user_Input.close();

		} catch (UnknownHostException e) {
			System.err.println("Unsure which host " + TLS_HOST); //if unable to connect then an error is shown
			System.exit(1);
		} catch (IOException e) {
			System.err.println("Unable to establish I/O connection to " + TLS_HOST); //if unable to connect then error is shown
			System.exit(1);
		}
	}

	private static class IncomingMessageHandler implements Runnable {
		private Socket socket;

		public IncomingMessageHandler(Socket socket) {
			this.socket = socket;
		}

		@Override
		public void run() {
			try {
				BufferedReader read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				String message;
				while ((message = read.readLine()) != null) { //checks the message is not equal to null and if not then the message is printed in the terminal
					System.out.println(message);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
